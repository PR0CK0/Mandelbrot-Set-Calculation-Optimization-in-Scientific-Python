'''
  @author: Tyler Procko
  @date:   Fall 2022

  TODO TODO TODO

  Ran out of time for this project.
'''

def mandelbrot_mpi():
  return 0
  
def mandelbrot_set_mpi(xMin, xMax, yMin, yMax, width, height, maxIterations):
  return 0